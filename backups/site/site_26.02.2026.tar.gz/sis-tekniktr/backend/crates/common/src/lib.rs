pub mod models;

pub fn init_common() {
    println!("Common module initialized");
}
